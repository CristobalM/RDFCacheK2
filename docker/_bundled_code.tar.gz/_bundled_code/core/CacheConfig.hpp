#ifndef _CACHE_CONFIG_HPP_
#define _CACHE_CONFIG_HPP_

#include <string>

struct CacheConfig {
  std::string cache_file_path;
};

#endif /* _CACHE_CONFIG_HPP_ */
