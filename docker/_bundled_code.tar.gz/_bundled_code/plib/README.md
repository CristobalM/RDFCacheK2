# Persistent Libs

Libraries here are attached to the project as snapshots to avoid incompatibilities
created by changes in their main repositories. This was done because an URL of
a given version wasn't found.


* Rax: https://github.com/antirez/rax (snapshot May 31, 2020. 1927550cb218ec3c3dda8b39d82d1d019bf0476d)
