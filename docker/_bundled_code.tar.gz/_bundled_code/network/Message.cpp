//
// Created by Cristobal Miranda, 2020
//

#include <iostream>
#include <netinet/in.h>
#include <utility>

#include "Message.hpp"

Message::Message(uint32_t message_size)
    : message_size(message_size),
      buffer(std::make_unique<char[]>(message_size)) {}

proto_msg::MessageType Message::request_type() {
  return deserialized->request_type();
}

char *Message::get_buffer() { return buffer.get(); }

size_t Message::get_size() { return message_size; }

void Message::deserialize() {
  deserialized = std::make_unique<proto_msg::CacheRequest>();
  deserialized->ParseFromArray(buffer.get(), message_size);
}

proto_msg::CacheRequest &Message::get_cache_request() { return *deserialized; }
