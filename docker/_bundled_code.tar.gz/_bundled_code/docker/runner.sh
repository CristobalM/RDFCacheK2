#!/bin/bash
/RDFCacheK2/_bundled_code/build/${@}
