#include "definitions.h"

DEFINE_READ_ELEMENT(uint, uint32_t)
DEFINE_READ_ELEMENT(block, struct block *)
