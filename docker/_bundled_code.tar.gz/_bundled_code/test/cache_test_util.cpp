
#include "cache_test_util.hpp"

#include <filesystem>
#include <fstream>
#include <iostream>

#include <K2TreeMixed.hpp>
#include <PredicatesIndexFileBuilder.hpp>
#include <serialization_util.hpp>

void build_cache_test_file(const std::string &fname,
                           std::vector<TripleValue> &data) {
  std::string plain_predicates_fname = fname + "plain_predicates_file.bin";
  {
    std::ofstream ofs_plain(plain_predicates_fname,
                            std::ios::out | std::ios::binary | std::ios::trunc);

    write_u64(ofs_plain, data.size());
    for (auto &tvalue : data) {
      tvalue.write_to_file(ofs_plain);
    }
  }

  K2TreeConfig config;
  config.cut_depth = 10;
  config.max_node_count = 256;
  config.treedepth = 32;

  std::ifstream ifs_plain(plain_predicates_fname,
                          std::ios::in | std::ios::binary);

  std::string index_fname_tmp = fname + ".tmp";

  {
    std::ofstream ofs_index(fname,
                            std::ios::out | std::ios::binary | std::ios::trunc);
    std::fstream ofs_index_tmp(index_fname_tmp, std::ios::in | std::ios::out |
                                                    std::ios::binary |
                                                    std::ios::trunc);

    PredicatesIndexFileBuilder::build(ifs_plain, ofs_index, ofs_index_tmp,
                                      config);
  }

  std::filesystem::remove(plain_predicates_fname);
  std::filesystem::remove(index_fname_tmp);
}

void build_cache_test_file(const std::string &fname,
                           std::vector<TripleValue> &&data) {
  build_cache_test_file(fname, data);
}

std::vector<TripleValue> build_initial_values_triples_vector(uint64_t size) {
  std::vector<TripleValue> result;

  for (uint64_t i = 1; i <= size; i++) {
    result.emplace_back(i, i, i);
  }

  return result;
}

void build_cache_test_file(const std::string &fname) {
  build_cache_test_file(fname, {});
}

std::vector<std::vector<RDFResource>>
translate_table(QueryResult &input_query_result, Cache &cache) {
  std::vector<std::vector<RDFResource>> translated_table;
  auto &input_table = input_query_result.table();
  for (auto &row : input_table.data) {
    std::vector<RDFResource> translated_row;
    for (auto col : row) {
      if (col == 0) {
        RDFResource null_resource("NULL", RDFResourceType::RDF_TYPE_LITERAL);
        translated_row.push_back(null_resource);
      } else {
        RDFResource col_resource;
        if (col > cache.get_pcm().get_last_id()) {
          col_resource = input_query_result.get_extra_dict().extract_resource(
              col - cache.get_pcm().get_last_id());
        } else {
          col_resource = cache.extract_resource(col);
        }

        translated_row.push_back(col_resource);
      }
    }
    translated_table.push_back(std::move(translated_row));
  }
  return translated_table;
}
std::vector<std::vector<RDFResource>> translate_table(ResultTable &input_table,
                                                      Cache &cache) {
  std::vector<std::vector<RDFResource>> translated_table;
  for (auto &row : input_table.data) {
    std::vector<RDFResource> translated_row;
    for (auto col : row) {
      if (col == 0) {
        RDFResource null_resource("NULL", RDFResourceType::RDF_TYPE_LITERAL);
        translated_row.push_back(null_resource);
      } else {
        auto col_resource = cache.extract_resource(col);
        translated_row.push_back(col_resource);
      }
    }
    translated_table.push_back(std::move(translated_row));
  }
  return translated_table;
}

void print_table_debug(
    ResultTable &table,
    std::unordered_map<unsigned long, std::string> &reverse_map,
    const std::vector<std::vector<RDFResource>> &translated_table) {
  for (auto header : table.headers) {
    std::cout << reverse_map[header] << "\t\t";
  }
  std::cout << std::endl;

  for (auto &row : translated_table) {
    for (auto &res : row) {
      std::cout << res.value << "\t\t";
    }
    std::cout << std::endl;
  }

  std::cout << "total size: " << translated_table.size() << std::endl;
}

void print_table_debug2(QueryResult &query_result, Cache &cache) {
  auto &table = query_result.table();
  auto translated_table = translate_table(query_result, cache);

  auto &vim = query_result.get_vim();
  auto reverse_map = vim.reverse();
  print_table_debug(table, reverse_map, translated_table);
}
