# Graph Results Caching

This is an early attempt to cache results, a better approach might be caching full predicates
