//
// Created by Cristobal Miranda, 2020
//

#ifndef RDFCACHEK2_MUTABLEPAIR_HPP
#define RDFCACHEK2_MUTABLEPAIR_HPP

struct mutable_pair {
  unsigned long first;
  unsigned long second;
};

#endif