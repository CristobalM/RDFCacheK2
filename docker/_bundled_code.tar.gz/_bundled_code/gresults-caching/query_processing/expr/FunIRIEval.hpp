//
// Created by cristobal on 4/20/21.
//

#ifndef RDFCACHEK2_FUNIRIEVAL_HPP
#define RDFCACHEK2_FUNIRIEVAL_HPP

#include "ExprEval.hpp"
class FunIRIEval : public ExprEval {
public:
  using ExprEval::ExprEval;
};

#endif // RDFCACHEK2_FUNIRIEVAL_HPP
