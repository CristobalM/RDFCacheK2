//
// Created by cristobal on 4/20/21.
//

#ifndef RDFCACHEK2_ONEOFBASEEVAL_HPP
#define RDFCACHEK2_ONEOFBASEEVAL_HPP

#include "ExprEval.hpp"
class OneOfBaseEval : public ExprEval {
public:
  using ExprEval::ExprEval;
};

#endif // RDFCACHEK2_ONEOFBASEEVAL_HPP
