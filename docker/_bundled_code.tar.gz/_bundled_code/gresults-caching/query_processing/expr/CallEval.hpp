//
// Created by cristobal on 4/20/21.
//

#ifndef RDFCACHEK2_CALLEVAL_HPP
#define RDFCACHEK2_CALLEVAL_HPP

#include "ExprEval.hpp"
class CallEval : public ExprEval {
public:
  using ExprEval::ExprEval;
};

#endif // RDFCACHEK2_CALLEVAL_HPP
