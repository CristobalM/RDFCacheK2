//
// Created by cristobal on 4/20/21.
//

#ifndef RDFCACHEK2_CASTEVAL_HPP
#define RDFCACHEK2_CASTEVAL_HPP

#include "ExprEval.hpp"
class CastEval : public ExprEval {
public:
  using ExprEval::ExprEval;
};

#endif // RDFCACHEK2_CASTEVAL_HPP
