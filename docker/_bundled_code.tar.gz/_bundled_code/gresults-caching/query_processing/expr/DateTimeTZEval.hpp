//
// Created by cristobal on 4/20/21.
//

#ifndef RDFCACHEK2_DATETIMETZEVAL_HPP
#define RDFCACHEK2_DATETIMETZEVAL_HPP

#include "ExprEval.hpp"
class DateTimeTZEval : public ExprEval {
public:
  using ExprEval::ExprEval;
  void validate() override;
  void init() override;
  std::shared_ptr<TermResource> eval_resource(const row_t &row) override;
  std::string format_offset(const DateInfo &info);
};

#endif // RDFCACHEK2_DATETIMETZEVAL_HPP
