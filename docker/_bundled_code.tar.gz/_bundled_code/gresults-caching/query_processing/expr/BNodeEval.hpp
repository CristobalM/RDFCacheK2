//
// Created by cristobal on 4/20/21.
//

#ifndef RDFCACHEK2_BNODEEVAL_HPP
#define RDFCACHEK2_BNODEEVAL_HPP

#include "ExprEval.hpp"
class BNodeEval : public ExprEval {
public:
  using ExprEval::ExprEval;
};

#endif // RDFCACHEK2_BNODEEVAL_HPP
