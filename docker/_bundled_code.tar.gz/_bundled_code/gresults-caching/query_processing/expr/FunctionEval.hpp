//
// Created by cristobal on 4/20/21.
//

#ifndef RDFCACHEK2_FUNCTIONEVAL_HPP
#define RDFCACHEK2_FUNCTIONEVAL_HPP

#include "ExprEval.hpp"
class FunctionEval : public ExprEval {
public:
  using ExprEval::ExprEval;
};

#endif // RDFCACHEK2_FUNCTIONEVAL_HPP
